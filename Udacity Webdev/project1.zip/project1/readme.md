##Usage

To run, just build the enternainment_center.py

To add more movies ot show on page, add the dictionary of data to the movies_data list in the entertainment_center.py

*note* 

- the bootstrap makes the column alignment all weird if more movies are added
- ideally movie details should be fetched from a db or an external source's API